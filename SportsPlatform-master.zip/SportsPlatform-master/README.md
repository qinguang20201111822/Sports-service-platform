# Sports-service-platform
Provide sports information for teachers and students in the school。
# HTML、css、JavaScript、bootstrap、php、MySQL
## 适用搭建在window系统上，如果搭建在Linux上需要修改php里的SQL语句，改为小写。
