document.writeln("	<div id=\'footer\' class=\'auto\'>");
	document.writeln("		<div class=\'bottom\'>");
	document.writeln("			<a>体育服务平台</a>");
	document.writeln("		</div>");
	document.writeln("	</div>");
	document.writeln("</body>");
	document.writeln("</html>");