<?php
//传入数据库
header('Content-type:text/html;charset=utf-8');//防止乱码
define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASSWORD','123456');
define('DB_DATABASE','qgbbs');
define('DB_PORT','3306');





?>