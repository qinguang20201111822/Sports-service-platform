<div id="footer" class="auto">
	<div class="bottom">
		<a>体育服务平台</a>
	</div>
</div>
</body>

</html>